import React, { useState } from 'react';
import { YoutubeIcon, Wand2, Link } from 'lucide-react';
import { extractVideoId } from '../lib/utils';
import { useLanguage } from '../contexts/LanguageContext';

interface ThumbnailFormProps {
  onGenerate: (prompt: string, videoUrl: string | null) => void;
}

export function ThumbnailForm({ onGenerate }: ThumbnailFormProps) {
  const { t } = useLanguage();
  const [prompt, setPrompt] = useState('');
  const [videoUrl, setVideoUrl] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!prompt && !videoUrl) {
      setError(t('errors.emptyFields'));
      return;
    }

    if (videoUrl && !extractVideoId(videoUrl)) {
      setError(t('errors.invalidUrl'));
      return;
    }

    onGenerate(prompt, videoUrl || null);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <div className="space-y-6">
        <div>
          <label htmlFor="prompt" className="block text-sm font-medium text-gray-700 mb-2">
            {t('promptLabel')}
          </label>
          <textarea
            id="prompt"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="w-full px-4 py-3 border border-gray-200 rounded-xl input-focus bg-white/50 backdrop-blur-sm"
            placeholder={t('promptPlaceholder')}
            rows={3}
          />
        </div>

        <div className="relative">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-gray-200" />
          </div>
          <div className="relative flex justify-center text-sm">
            <span className="px-4 bg-white/70 backdrop-blur-sm text-gray-500 rounded-full border border-gray-200">
              {t('or')}
            </span>
          </div>
        </div>

        <div>
          <label htmlFor="videoUrl" className="block text-sm font-medium text-gray-700 mb-2">
            {t('urlLabel')}
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
              <Link className="h-5 w-5 text-gray-400" />
            </div>
            <input
              id="videoUrl"
              type="url"
              value={videoUrl}
              onChange={(e) => setVideoUrl(e.target.value)}
              className="w-full pl-11 pr-4 py-3 border border-gray-200 rounded-xl input-focus bg-white/50 backdrop-blur-sm"
              placeholder={t('urlPlaceholder')}
            />
          </div>
        </div>
      </div>

      {error && (
        <p className="text-red-500 text-sm bg-red-50 px-4 py-2 rounded-lg">
          {error}
        </p>
      )}

      <button type="submit" className="btn-primary w-full flex items-center justify-center gap-2">
        <Wand2 className="h-5 w-5" />
        {t('generateButton')}
      </button>
    </form>
  );
}